<template lang="pug">
.graph-filter-container
  el-tabs(v-model="currentScene" type="card")
    el-tab
</template>

<script setup lang="ts">
import { ref } from "vue";

// 这里可以添加 props、emits、逻辑等
const filterConfig = [
  {
    value: "caseJudge",
    name: "案件研判场景",
    relationFilters: [
      {
        label: "虚实关联",
        value: "virtualRealRelation",
        enable: true,
        children: [
          {
            label: "手机设备关联",
            value: "phoneDeviceRelation",
            enable: true,
          },
          {
            label: "电脑设备关联",
            value: "computerDeviceRelation",
            enable: true,
          },
          {
            label: "社交账号关联",
            value: "socialAccountRelation",
            enable: true,
          },
        ],
      },
    ],
    nodeRiskFilters: [
      {
        label: "涉案关联",
        value: "caseRelated",
        enable: true,
      },
    ],
  },
  {
    value: "personRelation",
    name: "人员关系场景",
    relationFilters: [
      {
        label: "风险行为关系",
        value: "riskBehaviorRelation",
        enable: true,
        children: [
          {
            label: "风险行为关联",
            value: "riskBehaviorRelation",
            enable: true,
          },
        ],
      },
    ],
    nodeRiskFilters: [
      {
        label: "涉案关联",
        value: "caseRelated",
        enable: true,
      },
    ],
  },
];
const currentScene = ref("caseJudge");
</script>

<style scoped>
.graph-filter-container {
  width: 256px;
  min-height: 100vh;
  background: #f5f7fa;
  box-shadow: 2px 0 8px rgba(0, 0, 0, 0.04);
  padding: 16px;
  box-sizing: border-box;
}
</style>
